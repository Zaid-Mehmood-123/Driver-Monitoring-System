document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const videoFeed = document.getElementById('video-feed');
    const statusIndicator = document.getElementById('status-indicator');
    const statusText = document.getElementById('status-text');
    const sessionDuration = document.getElementById('session-duration');
    const alertCount = document.getElementById('alert-count');
    const startBtn = document.getElementById('start-btn');
    const stopBtn = document.getElementById('stop-btn');
    const settingsBtn = document.getElementById('settings-btn');
    const loginModal = document.getElementById('login-modal');
    const settingsModal = document.getElementById('settings-modal');
    const closeButtons = document.querySelectorAll('.close');
    const alertSound = document.getElementById('alert-sound');
    const sensitivitySlider = document.getElementById('sensitivity');
    const sensitivityValue = document.getElementById('sensitivity-value');
    const alertVolumeSlider = document.getElementById('alert-volume');
    const volumeValue = document.getElementById('volume-value');
    const alertTypeSelect = document.getElementById('alert-type');
    const saveSettingsBtn = document.getElementById('save-settings');

    // State variables
    let isMonitoring = false;
    let sessionStartTime = null;
    let sessionTimer = null;
    let checkDrowsinessInterval = null;
    let isUserLoggedIn = true;

    // Settings
    let settings = {
        sensitivity: 5,
        alertVolume: 7,
        alertType: 'both'
    };

    // Event Listeners
    window.addEventListener('load', handlePageLoad);
    closeButtons.forEach(button => button.addEventListener('click', closeModals));
    window.addEventListener('click', handleWindowClick);
    startBtn.addEventListener('click', handleStartMonitoring);
    stopBtn.addEventListener('click', handleStopMonitoring);
    settingsBtn.addEventListener('click', handleSettingsOpen);
    sensitivitySlider.addEventListener('input', updateSensitivity);
    alertVolumeSlider.addEventListener('input', updateVolume);
    saveSettingsBtn.addEventListener('click', saveSettings);

    // Initialize audio settings
    alertSound.volume = settings.alertVolume / 10;
    alertSound.preload = 'auto';

    // Functions
    function handlePageLoad() {
        if (!isUserLoggedIn) loginModal.style.display = 'block';
    }

    function closeModals() {
        loginModal.style.display = 'none';
        settingsModal.style.display = 'none';
    }

    function handleWindowClick(event) {
        if (event.target === loginModal) loginModal.style.display = 'none';
        if (event.target === settingsModal) settingsModal.style.display = 'none';
    }

    function handleStartMonitoring() {
        if (!isUserLoggedIn) {
            loginModal.style.display = 'block';
            return;
        }

        fetch('/start_monitoring', { method: 'POST' })
            .then(() => {
                isMonitoring = true;
                startBtn.disabled = true;
                stopBtn.disabled = false;
                statusIndicator.className = 'status-normal';
                statusText.textContent = 'Monitoring...';
                
                // Reset counters and timers
                alertCount.textContent = '0';
                sessionStartTime = new Date();
                sessionTimer = setInterval(updateSessionDuration, 1000);
                startDrowsinessDetection();
            })
            .catch(error => console.error('Start monitoring error:', error));
    }

    function handleStopMonitoring() {
        fetch('/stop_monitoring', { method: 'POST' })
            .then(() => {
                isMonitoring = false;
                startBtn.disabled = false;
                stopBtn.disabled = true;
                statusIndicator.className = 'status-normal';
                statusText.textContent = 'Monitoring stopped';
                
                clearInterval(sessionTimer);
                stopDrowsinessDetection();
            })
            .catch(error => console.error('Stop monitoring error:', error));
    }

    function handleSettingsOpen() {
        if (!isUserLoggedIn) {
            loginModal.style.display = 'block';
            return;
        }
        
        sensitivitySlider.value = settings.sensitivity;
        sensitivityValue.textContent = settings.sensitivity;
        alertVolumeSlider.value = settings.alertVolume;
        volumeValue.textContent = settings.alertVolume;
        alertTypeSelect.value = settings.alertType;
        settingsModal.style.display = 'block';
    }

    function updateSensitivity() {
        sensitivityValue.textContent = this.value;
    }

    function updateVolume() {
        volumeValue.textContent = this.value;
    }

    function saveSettings() {
        settings = {
            sensitivity: parseInt(sensitivitySlider.value),
            alertVolume: parseInt(alertVolumeSlider.value),
            alertType: alertTypeSelect.value
        };
        
        // Update audio settings
        alertSound.volume = settings.alertVolume / 10;
        console.log('Volume updated to:', alertSound.volume);
        
        // Handle iOS audio restrictions
        if (alertSound.paused) {
            alertSound.play().then(() => {
                alertSound.pause();
                alertSound.currentTime = 0;
            });
        }

        settingsModal.style.display = 'none';
    }

    function updateSessionDuration() {
        const now = new Date();
        const diff = now - sessionStartTime;
        const hours = Math.floor(diff / 3600000).toString().padStart(2, '0');
        const minutes = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
        const seconds = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
        sessionDuration.textContent = `${hours}:${minutes}:${seconds}`;
    }

    function startDrowsinessDetection() {
        checkDrowsinessInterval = setInterval(checkDrowsiness, 500);
    }

    function stopDrowsinessDetection() {
        clearInterval(checkDrowsinessInterval);
    }

    function checkDrowsiness() {
        if (!isMonitoring) return;
        
        fetch('/check_status')
            .then(response => response.json())
            .then(data => {
                alertCount.textContent = data.alert_count;
                
                if (data.drowsiness_detected || data.head_pose_alert) {
                    statusIndicator.className = 'status-alert';
                    statusText.textContent = 'ALERT!';
                    if (settings.alertType !== 'none') {
                        alertSound.currentTime = 0; // Reset audio to start
                        alertSound.play().catch(error => {
                            console.log('Audio play failed:', error);
                        });
                    }
                } else {
                    statusIndicator.className = 'status-normal';
                    statusText.textContent = 'Monitoring...';
                }
            })
            .catch(error => console.error('Drowsiness check error:', error));
    }


});